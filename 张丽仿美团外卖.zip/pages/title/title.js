//title.js
var indexData = require('../../util/data/index.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    scrTop:0,//距离顶部的距离
    nearShopData: [],//附近商家
  },
  // 计算星星数量
  jisuanStar: function (star) {
    //半个的星星
    var halfStar = (star.split(".")).pop();
    halfStar = halfStar > 5 ? 0 : 1;
    //完整的星星
    var allStar = parseInt(star) + (1 - halfStar);
    //未点量的星星
    var endStar = 5 - allStar - halfStar;
    return { "star": star, "allStar": allStar, "halfStar": halfStar, "endStar": endStar };
  },
  onLoad: function () {
    for (var i = 0; i < indexData.nearShopData.length; i++) {
      var itemData = indexData.nearShopData[i];
      var star = this.jisuanStar(itemData.star);
      indexData.nearShopData[i].jsStar = star;//增加新属性jsStar
    }
    this.setData({
      nearShopData: indexData.nearShopData
    })
  },
  onPageScroll: function (res) {
    // console.log(res.scrollTop);//打印页面滚动距离
    this.setData({
      scrTop: res.scrollTop
    })
    this.onLoad()
  },
  //跳转到商铺详情
  shopDetailClick: function(res){
    wx.navigateTo({
      url: './../detail/detail'
    })
  }
})