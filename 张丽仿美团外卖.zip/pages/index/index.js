//index.js
var indexData = require('../../util/data/index.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    scrTop:0,//距离顶部的距离
    topData:[],//顶部大类
    wnyxData:[],//为你优选数据
    nearShopData:[],//附近商家
  },
  // 计算星星数量
  jisuanStar: function(star){
    //半个的星星
    var halfStar = (star.split(".")).pop();
    halfStar = halfStar > 5 ? 0 : 1;
    //完整的星星
    var allStar = parseInt(star) + (1 - halfStar);
    //未点量的星星
    var endStar = 5 - allStar - halfStar;
    return { "star": star, "allStar": allStar, "halfStar": halfStar, "endStar": endStar};
  },
  onLoad: function(){
    for (var i = 0; i < indexData.nearShopData.length; i++){
      var itemData = indexData.nearShopData[i];
      var star = this.jisuanStar(itemData.star);
      indexData.nearShopData[i].jsStar = star;//增加新属性jsStar
    }
    this.setData({
      topData: indexData.topData,
      wnyxData: indexData.wnyxData,
      nearShopData: indexData.nearShopData
    })
    wx.getLocation({
      success: function(res){
        console.log(res);
        //发送网络请求获取信息
      }
    })
  },
  /* 类别类点击 */
  iconItemClick: function (res) {
    wx.navigateTo({
      url: './../title/title'
    })
  },
  /*商铺详情*/
  shopDetailClick: function (res) {
    wx.navigateTo({
      url: './../detail/detail'
    })
  },
  /*监听页面滚动*/
  onPageScroll: function (res) {
    // console.log(res.scrollTop);//打印页面滚动距离
    this.setData({
      scrTop: res.scrollTop
    })
  },
  /*排序按钮点击*/
  selectClick: function () {
    wx.pageScrollTo({
      scrollTop: 400,
      duration: 300
    })
  },
  /* 为你优选更多 */
  moreShop: function (){
    wx.navigateTo({
      url: './../shopArray/shopArray'
    })
  }
})
