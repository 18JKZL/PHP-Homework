// shopArray.js
var shopArrayData = require('../../util/data/shopArray.js');
Page({
  /**
     * 页面的初始数据
     */
  data: {
    shopArrayData:[],
  },
  onLoad: function () {
    this.setData({
      shopArrayData: shopArrayData.listArrData
    })
  },
  shopItemClick: function(){
    wx.navigateTo({
      url: './../detail/detail',
    })
  }
})