//detail.js
var indexData = require('../../util/data/detail.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    selIndex: 0,
    logo: '',//logo地址
    psTime: '',//配送时间
    detail: '',//描述
    active: [],//活动
    qiSong: 0,//起送价格
    countPrice: 0,//总价格
    menuList: [],//商家商品数据
    itemTit: 0,//菜单分类选中
    selectID: 'id_0',//菜单对应内容标题
    pingjiaData: [],//评价标签
    pjTypeSel: 0,//评价类型选择
    pjDetailData: [],//评价内容数组
    address:'',//商铺地址
    psSever:'',//配送服务
    openTime:'',//营业时间
  },
  onLoad: function(){
    var topData = indexData.topData;
    this.setData({
      logo: topData.logo,
      psTime: topData.psTime,
      detail: topData.detail,
      active: topData.active,
      qiSong: topData.qiSong,
      menuList: indexData.menuList,
      pingjiaData: indexData.pingjiaData,
      pjDetailData: indexData.pjDetailData,
      address: topData.address,
      psSever: topData.psSever,
      openTime: topData.openTime
    })
  },
  //减方法点击
  reduceClick: function(res){
    this.jisuanNumber('-',res);
    this.jisuanCountPrice();
  },
  //加方法点击
  addClick:function(res){
    this.jisuanNumber('+',res);
    this.jisuanCountPrice();
  },
  //计算数量
  jisuanNumber: function(end,res){
    var itemClick = res.currentTarget.dataset;//获取点击的标识
    var menuList = this.data.menuList;//获取数据
    var itemArray = menuList[itemClick.item];//获取标签下的数据
    var itemDetailArray = itemArray.count;//获取到标签下的数据列表
    var item = itemDetailArray[itemClick.index];//获取到点击的元素
    item.count = parseInt(item.count);//转为整数
    if (end == '+'){
      item.count += 1;//数据加一
      this.setData({
        menuList: menuList
      })
    }else{
      //去除负数情况
      if (item.count == 0) {
        return;
      }
      item.count -= 1;//数据减一
      this.setData({
        menuList: menuList
      })
    }
  },
  // 左侧目录滚动
  menuListScroll: function(res){
    console.log('左侧目录滚动'+res.detail.scrollTop);
  },
  // 右侧商品滚动
  shopDetailScroll: function(res){
    console.log('右侧商品滚动'+res.detail.scrollTop);
  },
  //计算总价格
  jisuanCountPrice:function(){
    var countPrice = 0;
    var menuList = this.data.menuList;
    for(var i = 0;i < menuList.length;i++){//遍历大的数据
      var itemArr = menuList[i].count;
      for (var j = 0; j < itemArr.length;j++){//遍历子的数据
        var item = itemArr[j];
        countPrice += Number(item.price) * Number(item.count);
      }
    }
    this.setData({
      countPrice: countPrice
    })
  },
  //菜单标签点击
  menuClick: function(){
    this.setData({
      selIndex: 0
    })
  },
  //评价标签点击
  pingjiaClick: function () {
    this.setData({
      selIndex: 1
    })
  },
  //商家标签点击
  shoppingClick: function () {
    this.setData({
      selIndex: 2
    })
  },
  // 底部内容滚动
  contentChange: function (event){
    var selIndex = event.detail.current;
    this.setData({
      selIndex: selIndex
    })
  },
  // 左侧菜单类型点击事件
  itemTitClick: function(res){
    var index = res.currentTarget.dataset.index;
    //让右侧菜单滚动到指定位置
    this.setData({
      itemTit: index,
      selectID: 'id_'+index,
    })
  },
  //评价类型点击事件
  pjTypeClick: function(res){
    this.setData({
      pjTypeSel: res.currentTarget.dataset.index
    })
    //发送网络请求获取对应类型的评价数据
  }
})