// detail.js
// 顶部数据
var topData = { "logo": "../../images/getImg/83f5fa588ae12840f2d68e72d1cfc40b46851.jpg", "psTime": "41", "detail": "本品牌有4家餐厅是深圳市食品安全规范示范单位。", "qiSong": "30", "active": ["80减30", "130减40", "5.76折起", "返5元券"], "address": "深圳市南山区粤海街道科苑路15号科兴科学园C栋G层17a", "psSever": "商家", "openTime":"10:00-22:30"}
var menuList = [
  {
    "title": "热销",
    "count":[
      { "image": "../../images/getImg/6d9e21576bdb21437d6604ece2a98a5b259489.jpg", "title": "金枕榴莲披萨9英寸", "detail": "精选泰国原产进口榴莲，果肉饱满。","sales":"463","goods":"4","price":"49.9","oldPrice":"79", "count":"0"},
      { "image": "../../images/getImg/45160e0493642a40ed71e99ba203bca7334938.jpg", "title": "奥尔良烤翅一对", "detail": "经典奥尔良风味，微辣", "sales": "248", "goods": "2", "price": "16", "oldPrice": "", "count": "0"},
      { "image": "../../images/getImg/b50dab0cf53efb53585ba68fc81eaa9d339379.jpg", "title": "乐小辣鸡中翅一对", "detail": "乐凯撒爆款小吃，麻麻辣辣，鲜嫩多汁。", "sales": "215", "goods": "2", "price": "16", "oldPrice": "", "count": "0"},
      { "image": "../../images/getImg/ce63a14849d249c2784311646358a9fc267428.jpg", "title": "金枕榴莲披萨12英寸", "detail": "精选泰国原产进口榴莲，果肉饱满，美味清香。", "sales": "196", "goods": "3", "price": "79", "oldPrice": "99", "count": "0"},
    ]
  },
  {
    "title": "折扣",
    "count": [
      { "image": "../../images/getImg/196b525238a3f4666e05df74b0df439c236147.jpg", "title": "香芒醉鸡一人超满足套餐", "detail": "套餐内含：9英寸爆果肉香芒醉鸡披萨1份+乐小辣鸡翅1对+可口可乐1罐", "sales": "21", "goods": "0", "price": "59.9", "oldPrice": "104", "count": "0"},
      { "image": "../../images/getImg/60eaacb47a8ea489d3316a1c9607854d270901.jpg", "title": "苏丹王榴莲卷芝士披萨", "detail": "更高级的榴莲，榴莲重度患者必选！", "sales": "11", "goods": "0", "price": "79", "oldPrice": "105", "count": "0"},
    ]
  },
  {
    "title": "果肉加量榴莲披萨",
    "count": [
      { "image": "../../images/getImg/8b7609bae6a475141eef14b49324557f252392.jpg", "title": "爆果肉金枕榴莲披萨12英寸", "detail": "果肉加量加量加量！精选泰国原产进口金枕榴莲。适合2~3人食用", "sales": "62", "goods": "1", "price": "129", "oldPrice": "", "count": "0"},
      { "image": "../../images/getImg/ce63a14849d249c2784311646358a9fc267428.jpg", "title": "马来西亚D24榴莲披萨12英寸", "detail": "精选马来西亚进口D24榴莲，榴莲味更浓厚", "sales": "37", "goods": "0", "price": "129", "oldPrice": "", "count": "0"},
      { "image": "../../images/getImg/60eaacb47a8ea489d3316a1c9607854d270901.jpg", "title": "马来西亚D24榴莲披萨9英寸", "detail": "精选马来西亚进口D24榴莲，榴莲味更浓厚", "sales": "17", "goods": "2", "price": "99", "oldPrice": "", "count": "0"},
    ]
  },
  {
    "title": "纯手工拍制披萨",
    "count": [
      { "image": "../../images/getImg/6763077c2f85506b6d694f3e85ddd0e9312251.jpg", "title": "蒲烧鳗鱼披萨12英寸", "detail": "没有腥味的日料级深海繁殖鳗鱼", "sales": "43", "goods": "0", "price": "119", "oldPrice": "", "count": "0"},
      { "image": "../../images/getImg/b7d523be79d0e19dd116f42565269de2261063.jpg", "title": "海鲜洋溢披萨12英寸", "detail": "寿司级松叶蟹腿肉混搭泰国白虾，加入菠萝，小朋友都爱吃", "sales": "35", "goods": "0", "price": "119", "oldPrice": "", "count": "0"},
      { "image": "../../images/getImg/b7d523be79d0e19dd116f42565269de2261063.jpg", "title": "海鲜洋溢披萨9英寸", "detail": "寿司级松叶蟹腿肉混搭泰国白虾，加入菠萝，小朋友都爱吃", "sales": "31", "goods": "2", "price": "89", "oldPrice": "", "count": "0"},
    ]
  },
  {
    "title": "超值大套餐",
    "count": [
      { "image": "../../images/getImg/006b2cb7efb3b4cc544bb94a66f9b9d1295313.jpg", "title": "超值双拼套餐", "detail": "泰国原产进口榴莲的金枕榴莲披萨", "sales": "47", "goods": "0", "price": "149", "oldPrice": "", "count": "0"},
      { "image": "../../images/getImg/556c088e33d4fce50265cf4bb0d05990296329.jpg", "title": "超值套餐", "detail": "可任选乐凯撒经典款", "sales": "42", "goods": "0", "price": "139", "oldPrice": "", "count": "0"},
    ]
  },
  {
    "title": "意面&甜品",
    "count": [
      { "image": "../../images/getImg/9056efa59323008945216a4c87e70081284498.jpg", "title": "经典牛肉酱意面", "detail": "不是猪肉的牛肉酱意面，饱腹无负担", "sales": "108", "goods": "2", "price": "39", "oldPrice": "", "count": "0"},
      { "image": "../../images/getImg/63114be1e566f0913de3a73faee4a582284660.jpg", "title": "宫保鸡丁意面", "detail": "把中国味道宫保鸡丁加进意面里，是你没吃过的好吃味道", "sales": "37", "goods": "1", "price": "39", "oldPrice": "", "count": "0"},
    ]
  },
  {
    "title": "吮指小吃",
    "count": [
      { "image": "../../images/getImg/54e10b946f830c648aa6070b2b8e6c85333519.jpg", "title": "墨墨鸡鸡块", "detail": "口感外酥内嫩，青芥末/香辣酱/番茄酱可选，一口一个好过瘾。", "sales": "65", "goods": "2", "price": "29", "oldPrice": "", "count": "0"},
      { "image": "../../images/getImg/7bb7fd7c0e58ec62f209c10dcdf63424308836.jpg", "title": "拉丁烤肠", "detail": "一份四串，咸香风味，外脆里嫩", "sales": "173", "goods": "2", "price": "29", "oldPrice": "", "count": "0"},
      { "image": "../../images/getImg/45160e0493642a40ed71e99ba203bca7334938.jpg", "title": "奥尔良烤翅一对", "detail": "经典奥尔良风味，微辣", "sales": "248", "goods": "2", "price": "16", "oldPrice": "", "count": "0" },
    ]
  },
  {
    "title": "果汁饮品",
    "count": [
      { "image": "../../images/getImg/babd3f8cfa86aa1aa4264c1c1564d73b332305.jpg", "title": "酷椰屿椰子水", "detail": "", "sales": "7", "goods": "0", "price": "19", "oldPrice": "", "count": "0"},
      { "image": "../../images/getImg/4fb40df8d7fe4e89c89dda7982c320c4319029.jpg", "title": "可口可乐", "detail": "听装（冷藏）", "sales": "63", "goods": "0", "price": "9", "oldPrice": "", "count": "0"},
      { "image": "../../images/getImg/267e0c2bee6358dc11abb87b8b42d43a325090.jpg", "title": "雪碧", "detail": "听装（冷藏）", "sales": "26", "goods": "0", "price": "9", "oldPrice": "", "count": "0" },
    ]
  },
];
var pingjiaData = [
  { "title":"全部", "count":"7099"},
  { "title": "有图评价", "count": "214"},
  { "title": "好评", "count": "6957" },
  { "title": "差评", "count": "75" },
  { "title": "味道赞", "count": "421" },
  { "title": "服务好", "count": "363" },
  { "title": "满意", "count": "75" },
  { "title": "披萨不错", "count": "34" },
  { "title": "包装好", "count": "27" },
  { "title": "下午茶", "count": "21" },
];
var pjDetailData = [
  { "icon": "../../images/detail/placeholder.png", "nickName": '匿名用户', "time": "2019.03.09", "star": 4, "sdtime": "39", "detail": "面饼是带火龙果吗？10086个赞","images":[],"hfDetail":""},
  { "icon": "../../images/detail/placeholder.png", "nickName": '匿名用户', "time": "2019.02.12", "star": 5, "sdtime": "1033", "detail": "吃的很过瘾。很喜欢乐凯撒披萨。感谢外卖小哥", "images": [], "hfDetail": "" },
  { "icon": "../../images/detail/placeholder.png", "nickName": '匿名用户', "time": "2019.01.21", "star": 3, "sdtime": "1033", "detail": "土豆味道很辣，喜欢吃辣的人不要错过", "images": [], "hfDetail": "" },
  { "icon": "../../images/detail/placeholder.png", "nickName": '匿名用户', "time": "2019.02.12", "star": 5, "sdtime": "1033", "detail": "美味，套餐实惠。", "images": [], "hfDetail": "" },
  { "icon": "../../images/detail/placeholder.png", "nickName": '匿名用户', "time": "2019.03.10", "star": 5, "sdtime": "1033", "detail": "榴莲pizza还是乐凯撒好吃！", "images": [], "hfDetail": "" },
];
// 输出数据
module.exports = {
  topData: topData,
  menuList: menuList,
  pingjiaData: pingjiaData,
  pjDetailData: pjDetailData,
}