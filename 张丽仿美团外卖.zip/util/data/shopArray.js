// shopArray.js
var listArrData = [
  { "logo": "../../images/getImg/83f5fa588ae12840f2d68e72d1cfc40b46851.jpg", "name": "乐凯撒披萨", "qsCount": "30", "psCount": "5", "ypsCount": "5", "rjCount": "38","active":"满80减30;满130减40","detail":[
    { "image": "../../images/getImg/6d9e21576bdb21437d6604ece2a98a5b259489.jpg", "title": "金枕榴莲披萨", "price": "49.9", "oldPrice": "79"},
    { "image": "../../images/getImg/45160e0493642a40ed71e99ba203bca7334938.jpg", "title": "奥尔良烤翅一对", "price": "16", "oldPrice": ""},
    { "image": "../../images/getImg/b50dab0cf53efb53585ba68fc81eaa9d339379.jpg", "title": "乐小辣鸡中翅", "price": "16", "oldPrice": ""}
  ]},
  {
    "logo": "../../images/getImg/e802fb9741736905678a25f006842b37187047.png", "name": "真功夫", "qsCount": "5", "psCount": "5", "ypsCount": "", "rjCount": "", "active": "满50减20", "detail": [
      { "image": "../../images/getImg/0963887a1914120bcfaf7b964580df58235821.jpg", "title": "排骨饭汤套餐", "price": "34.5", "oldPrice": "" },
      { "image": "../../images/getImg/5a1744314a61b0d5ccb6dfbb2095484e209241.jpg", "title": "鱼香茄子饭套餐", "price": "25", "oldPrice": "" },
      { "image": "../../images/getImg/62b3fe133535f95e6fb03e4c8d79dd2a1442125.jpg", "title": "酱香花腩汤套餐", "price": "32", "oldPrice": "" }
    ]
  },
  {
    "logo": "../../images/getImg/3c29d8f35d12d05d1a756fb0c5931ba128688.jpeg", "name": "绿茶餐厅", "qsCount": "20", "psCount": "7", "ypsCount": "9", "rjCount": "", "active": "满40减20", "detail": [
      { "image": "../../images/getImg/b79612e14110cc318d62a2bcff73611a372841.jpg", "title": "绿茶葱香烤鸡", "price": "32", "oldPrice": "50" },
      { "image": "../../images/getImg/dd7fa7e28879b1cd761265c97c8f1e541103399.jpg", "title": "绿茶葱香烤肉", "price": "38", "oldPrice": "" },
      { "image": "../../images/getImg/bd2509826fc9d908315e55da805ac8a31138103.jpg", "title": "葱香烤鸡肉合拼", "price": "58", "oldPrice": "" }
    ]
  },
];
// 输出数据
module.exports = {
  listArrData: listArrData
}