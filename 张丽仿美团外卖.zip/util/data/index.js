// index.js
//顶部分类数据
var topData = [
  { "image": "../../images/index/icon_home_category_code_1.png", "title": "美食" },
  { "image": "../../images/index/icon_home_category_code_2.png", "title": "超市便利" },
  { "image": "../../images/index/icon_home_category_code_3.png", "title": "生鲜果蔬" },
  { "image": "../../images/index/icon_home_category_code_4.png", "title": "美团专送" },
  { "image": "../../images/index/icon_home_category_code_5.png", "title": "甜点饮品" },
  { "image": "../../images/index/icon_home_category_code_6.png", "title": "浪漫鲜花" },
  { "image": "../../images/index/icon_home_category_code_7.png", "title": "送药上门" },
  { "image": "../../images/index/icon_home_category_code_8.png", "title": "午餐优选" },
  { "image": "../../images/index/icon_home_category_code_9.png", "title": "小吃馆" },
  { "image": "../../images/index/icon_home_category_code_10.png", "title": "日韩料理" }
];
//为你优选数据
var wnyxData = [
  { "bgImage": "../../images/getImg/0963887a1914120bcfaf7b964580df58235821.jpg", "icon":"../../images/getImg/e802fb9741736905678a25f006842b37187047.png","nickname":"真功夫","detail":"快餐简餐中的点评达人","tag":"38减11"},
  { "bgImage": "../../images/getImg/ce63a14849d249c2784311646358a9fc267428.jpg", "icon": "../../images/getImg/83f5fa588ae12840f2d68e72d1cfc40b46851.jpg", "nickname": "乐凯撒披萨", "detail": "根据你看过的店铺推荐", "tag": "80减30" },
  { "bgImage": "../../images/getImg/4c34b93cbe7476f3f82619e41f4229f01237866.jpg", "icon": "../../images/getImg/bacd2174b91b38736409f258c0cc6ffc83787.jpeg", "nickname": "义泰昌现炒快餐", "detail": "根据你看过的店铺推荐", "tag": "25减11" },
  { "bgImage": "../../images/getImg/b79612e14110cc318d62a2bcff73611a372841.jpg", "icon": "../../images/getImg/3c29d8f35d12d05d1a756fb0c5931ba128688.jpeg", "nickname": "绿茶餐厅", "detail": "江浙菜中的点评人气王", "tag": "40减20" },
  { "bgImage": "../../images/getImg/fe059ead41c83a5c4f41d5c187271f34884548.jpg", "icon": "../../images/getImg/6d8b1c1c820a47608610fc2b283ea18624591.jpg", "nickname": "九龙冰室", "detail": "根据你看过的店铺推荐", "tag": "50减8" }
];
//附近商家数据
var nearShopData = [
  {"logo": "../../images/getImg/83f5fa588ae12840f2d68e72d1cfc40b46851.jpg", "name": "乐凯撒披萨", "star": "3.8","sales":"2069","long":"1.0km","time":"41分钟","qsCount":"30","psCount":"5","ypsCount":"5","rjCount":"38","type":"西餐快餐","active":["80减30","130减40","5.76折起","返5元券"],"tag":[]},
  { "logo": "../../images/getImg/bacd2174b91b38736409f258c0cc6ffc83787.jpeg", "name": "义泰昌现炒快餐", "star": "4.4", "sales": "6209", "long": "1.6km", "time": "40分钟", "qsCount": "20", "psCount": "4", "ypsCount": "", "rjCount": "26", "type": "中式简餐", "active": ["25减11", "35减14", "50减20", "4.54折起"], "tag": ["支持自取"] },
  { "logo": "../../images/getImg/339aeb47a0bff9d6ae6910309deb9aa811035.jpg", "name": "三米粥铺", "star": "4.2", "sales": "9999+", "long": "1.1km", "time": "40分钟", "qsCount": "20", "psCount": "2", "ypsCount": "", "rjCount": "26", "type": "中式简餐", "active": ["28减16", "56减20", "80减23", "新客减1"], "tag": ["支持自取"] },
  { "logo": "../../images/getImg/64cc287151ab081a5749358005a8680b21921.jpg", "name": "一点点", "star": "4.2", "sales": "3418", "long": "937m", "time": "46分钟", "qsCount": "40", "psCount": "5", "ypsCount": "", "rjCount": "", "type": "奶茶果汁", "active": ["首单减16"], "tag": ["支持自取"] },
  { "logo": "../../images/getImg/11484124d09ce54ca8cf314b3d60247f190385.png", "name": "如轩海鲜砂锅粥", "star": "4.3", "sales": "246", "long": "326m", "time": "44分钟", "qsCount": "20", "psCount": "2", "ypsCount": "7", "rjCount": "", "type": "中式简餐", "active": ["50减5", "80减10", "100减15", "6.6折起"], "tag": [] },
  { "logo": "../../images/getImg/5c77c6a7a7928676a3a415352ec1d07926341.jpg", "name": "千百味（酸菜鱼）", "star": "4.3", "sales": "603", "long": "1.7km", "time": "40分钟", "qsCount": "20", "psCount": "2", "ypsCount": "", "rjCount": "", "type": "中式简餐", "active": ["30减20", "50减26", "80减37", "100减47"], "tag": [] },  
  { "logo": "../../images/getImg/12e161f50d3d56c089f08360b23c938552460.png", "name": "66DERTEA", "star": "4.8", "sales": "213", "long": "1.2km", "time": "30分钟", "qsCount": "20", "psCount": "3", "ypsCount": "", "rjCount": "", "type": "奶茶果汁", "active": ["23减19", "55减25", "4.97折"], "tag": ["支持自取","急速退款"] },  
  { "logo": "../../images/getImg/45815eb36ffc435c3a1ca4caee1a0a8e41802.jpg", "name": "螺阿玛柳州螺蛳粉", "star": "4.3", "sales": "1034", "long": "3.9km", "time": "45分钟", "qsCount": "20", "psCount": "1", "ypsCount": "3", "rjCount": "13", "type": "米粉米线", "active": ["15减7", "30减10", "50减15","100减20"], "tag": ["急速退款"] }, 
];
// 输出数据
module.exports = {
  topData: topData,
  wnyxData: wnyxData,
  nearShopData: nearShopData,
}